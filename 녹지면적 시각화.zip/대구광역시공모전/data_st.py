#Streamlit 대시보드용 데이터 처리

"""
Streamlit 대시보드용 데이터 처리 (pandas만 사용)
- app.py와 같은 폴더에 두세요.
- 필요 파일: data/GreenArea.csv, data/{연도}_ASOS.csv, heat_data.py
"""
import os
from pathlib import Path

import pandas as pd

BASE = Path(__file__).resolve().parent
os.chdir(BASE)  # heat_data.py가 "data/..." 상대경로를 쓰기 때문에 실행 위치를 고정

GREEN_TYPES = ["활엽수림", "침엽수림", "혼효림", "자연초지"]


def load_asos(start=2016, end=2025):
    """ASOS 6~8월 연도별 평균최고기온, 열대야일수 (main.py와 같은 기준)"""
    rows = []
    for year in range(start, end + 1):
        path = BASE / "data" / f"{year}_ASOS.csv"
        if not path.exists():
            continue
        d = pd.read_csv(path, encoding="cp949")
        d["일시"] = pd.to_datetime(d["일시"])
        s = d[d["일시"].dt.month.isin([6, 7, 8])]
        mx = pd.to_numeric(s["최고기온(°C)"], errors="coerce")
        mn = pd.to_numeric(s["최저기온(°C)"], errors="coerce")
        rows.append({
            "연도": year,
            "평균최고기온": round(mx.mean(), 2),
            "열대야일수": int((mn >= 25).sum()),
        })
    return pd.DataFrame(rows)


def _flatten(col):
    parts = []
    for c in col:
        c = str(c).strip()
        if not c.startswith("Unnamed") and c not in parts:
            parts.append(c)
    return "_".join(parts)


def load_green():
    """대구 구·군별 녹지면적(㎢), 구 전체 면적(㎢), 녹지율(%) — 9개 구·군 전체"""
    G = pd.read_csv(BASE / "data" / "GreenArea.csv", encoding="cp949", header=[0, 1, 2])
    G.columns = [_flatten(c) for c in G.columns]
    G = G.rename(columns={G.columns[0]: "시도", G.columns[1]: "행정구"})
    g = G[G["시도"].astype(str).str.startswith("대구광역시")
          & ~G["행정구"].astype(str).str.strip().isin(["소계", "합계"])].copy()

    green_cols = [c for c in g.columns
                  if any(k in c for k in GREEN_TYPES) and "면적" in c]
    total_col = [c for c in g.columns if "총합계" in c and "면적" in c][0]
    for c in green_cols + [total_col]:
        g[c] = pd.to_numeric(g[c].astype(str).str.replace(",", "").str.strip(),
                             errors="coerce").fillna(0)

    out = pd.DataFrame({
        "행정구": g["행정구"].astype(str).str.strip(),
        "녹지면적_km2": g[green_cols].sum(axis=1) / 1e6,
        "전체면적_km2": g[total_col] / 1e6,
    })
    out["녹지율"] = out["녹지면적_km2"] / out["전체면적_km2"] * 100
    return out.reset_index(drop=True)


def load_heat():
    """heat_data.py의 구·군별 평균최고기온, 열대야일수 표"""
    from heat_data import heat
    return heat.copy()


def build_result(green, heat, exclude=(), w_heat=0.5):
    """녹지 + 기온 결합 → 열섬지수, 녹지부족지수, 우선조성점수, 4분면 구분"""
    df = green.merge(heat, on="행정구", how="inner")
    df = df[~df["행정구"].isin(list(exclude))].reset_index(drop=True)

    def mm(s):
        rng = s.max() - s.min()
        return (s - s.min()) / (rng if rng else 1)

    df["열섬지수"] = (mm(df["평균최고기온"]) + mm(df["열대야일수"])) / 2
    df["녹지부족지수"] = 1 - mm(df["녹지율"])
    df["우선조성점수"] = w_heat * df["열섬지수"] + (1 - w_heat) * df["녹지부족지수"]
    df = df.sort_values("우선조성점수", ascending=False).reset_index(drop=True)
    df["우선순위"] = df.index + 1

    t_mid, g_mid = df["열섬지수"].median(), df["녹지율"].median()

    def grade(r):
        hot, poor = r["열섬지수"] >= t_mid, r["녹지율"] < g_mid
        return "최우선" if hot and poor else "열 관리" if hot else "녹지 확충" if poor else "양호"

    df["구분"] = df.apply(grade, axis=1)
    return df, t_mid, g_mid