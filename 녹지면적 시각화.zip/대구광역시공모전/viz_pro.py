"""
대구 구·군별 녹지 현황 vs 폭염(평균최고기온·열대야) 종합 시각화
- main.py, heat_data.py와 같은 폴더에 두고 실행하세요.
- 필요 파일: data/GreenArea.csv, heat_data.py (heat 표)
"""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
from matplotlib.lines import Line2D

# ───────────────────────── 0. 설정 ─────────────────────────
# 서구·달성군 AWS 파일이 완전히 동일(지점 828)합니다. 한쪽이 잘못 받은 파일이므로
# 다시 받기 전까지 제외합니다. 제대로 받았다면 빈 리스트 []로 바꾸세요.
EXCLUDE = ["서구"]

# 한글 폰트: 설치된 것 중 먼저 발견되는 것을 사용 (Windows/Mac/Linux 모두 대응)
for name in ["Malgun Gothic", "AppleGothic", "NanumGothic", "Noto Sans CJK KR", "Noto Sans CJK JP"]:
    if any(name == f.name for f in fm.fontManager.ttflist):
        plt.rcParams["font.family"] = name
        break
plt.rcParams["axes.unicode_minus"] = False

BG, INK, GRID = "#FFFFFF", "#1F2933", "#E4E7EB"
RED, ORANGE, BLUE, GREEN = "#C0392B", "#E67E22", "#2E6F9E", "#3A8F5C"
plt.rcParams.update({
    "figure.facecolor": BG, "axes.facecolor": BG, "axes.edgecolor": GRID,
    "axes.labelcolor": INK, "text.color": INK, "xtick.color": INK, "ytick.color": INK,
    "axes.spines.top": False, "axes.spines.right": False,
})

# ───────────────────────── 1. 녹지 데이터 ─────────────────────────
Green = pd.read_csv("data/GreenArea.csv", encoding="cp949", header=[0, 1, 2])

def flatten(col):
    parts = []
    for c in col:
        c = str(c).strip()
        if not c.startswith("Unnamed") and c not in parts:
            parts.append(c)
    return "_".join(parts)

Green.columns = [flatten(c) for c in Green.columns]
Green = Green.rename(columns={Green.columns[0]: "시도", Green.columns[1]: "행정구"})
g = Green[Green["시도"].astype(str).str.startswith("대구광역시")
          & ~Green["행정구"].astype(str).str.strip().isin(["소계", "합계"])].copy()

green_cols = [c for c in g.columns
              if any(k in c for k in ["활엽수림", "침엽수림", "혼효림", "자연초지"]) and "면적" in c]
total_col = [c for c in g.columns if "총합계" in c and "면적" in c][0]   # 구 전체 면적(토지피복 합계)

for c in green_cols + [total_col]:
    g[c] = pd.to_numeric(g[c].astype(str).str.replace(",", "").str.strip(), errors="coerce").fillna(0)

g["녹지면적"] = g[green_cols].sum(axis=1)
g["녹지율"] = g["녹지면적"] / g[total_col] * 100          # ★ 구 크기 보정 (%)
g = g[["행정구", "녹지면적", "녹지율"]]

# ───────────────────────── 2. 기온 데이터 결합 ─────────────────────────
from heat_data import heat          # (행정구, 평균최고기온, 열대야일수, 폭염일수)

df = g.merge(heat, on="행정구", how="inner")
df = df[~df["행정구"].isin(EXCLUDE)].reset_index(drop=True)
missing = sorted(set(g["행정구"]) - set(heat["행정구"]) | set(EXCLUDE))
print("기온 데이터 없음/제외:", missing)

# ───────────────────────── 3. 지수 계산 ─────────────────────────
mm = lambda s: (s - s.min()) / (s.max() - s.min())
df["열섬지수"] = (mm(df["평균최고기온"]) + mm(df["열대야일수"])) / 2   # 낮 기온 + 밤 열대야
df["녹지부족지수"] = 1 - mm(df["녹지율"])
df["우선조성점수"] = (df["열섬지수"] + df["녹지부족지수"]) / 2
df = df.sort_values("우선조성점수", ascending=False).reset_index(drop=True)
df["우선순위"] = df.index + 1

t_mid, g_mid = df["열섬지수"].median(), df["녹지율"].median()
def grade(r):
    hot, poor = r["열섬지수"] >= t_mid, r["녹지율"] < g_mid
    return "최우선" if hot and poor else "열 관리" if hot else "녹지 확충" if poor else "양호"
df["구분"] = df.apply(grade, axis=1)
COLOR = {"최우선": RED, "열 관리": ORANGE, "녹지 확충": BLUE, "양호": GREEN}

print(df[["우선순위", "행정구", "녹지율", "평균최고기온", "열대야일수", "우선조성점수", "구분"]].round(2).to_string(index=False))

# ───────────────────────── 4. 대시보드 ─────────────────────────
fig = plt.figure(figsize=(20, 11))
gs = fig.add_gridspec(2, 2, width_ratios=[1.25, 1], height_ratios=[1, 0.62],
                      hspace=0.42, wspace=0.22, left=0.06, right=0.97, top=0.88, bottom=0.07)
fig.suptitle("대구 구·군별 녹지 현황과 폭염 취약도", fontsize=21, fontweight="bold", x=0.06, ha="left", y=0.965)
fig.text(0.06, 0.915, "녹지율(활엽수림·침엽수림·혼효림·자연초지 / 구 전체 면적, 2024)과 "
         "열섬지수(평균최고기온·열대야일수, AWS 관측소, 2026.7)의 관계", fontsize=11.5, color="#52606D")

# (A) 산점도: 녹지율 × 열섬지수, 버블=녹지면적
ax = fig.add_subplot(gs[0, 0])
ax.axvline(g_mid, ls="--", lw=1, color="#9AA5B1")
ax.axhline(t_mid, ls="--", lw=1, color="#9AA5B1")
xmax = df["녹지율"].max() * 1.15
ymin, ymax = -0.3, 1.2
ax.fill_between([-5, g_mid], t_mid, ymax, color=RED, alpha=0.07, zorder=0)       # 최우선 구역 음영
ax.text(g_mid / 2, ymax - 0.04, "최우선 조성 구역", color=RED, fontsize=11,
        fontweight="bold", va="top", ha="center")

size = 250 + 2200 * mm(np.sqrt(df["녹지면적"]))
ax.scatter(df["녹지율"], df["열섬지수"], s=size, c=df["구분"].map(COLOR),
           alpha=0.85, edgecolor="white", linewidth=2, zorder=3)
for _, r in df.iterrows():
    ax.annotate(r["행정구"], (r["녹지율"], r["열섬지수"]), xytext=(0, -(np.sqrt(size[_]) / 2 + 9)),
                textcoords="offset points", ha="center", va="top", fontsize=11.5, fontweight="bold")
if len(df) >= 4:
    k, b = np.polyfit(df["녹지율"], df["열섬지수"], 1)
    xs = np.linspace(-5, xmax, 50)
    ax.plot(xs, k * xs + b, color="#52606D", lw=1.4, ls=":", zorder=2)
    rho = df[["녹지율", "열섬지수"]].corr(method="spearman").iloc[0, 1]
    ax.text(0.02, 0.04, f"Spearman ρ = {rho:.2f}  (n={len(df)}, 참고용)", transform=ax.transAxes,
            ha="left", fontsize=10, color="#52606D")
ax.set_xlim(-5, xmax); ax.set_ylim(ymin, ymax)
ax.set_xlabel("녹지율 (%)  →  높을수록 녹지가 풍부")
ax.set_ylabel("열섬지수 (평균최고기온 + 열대야일수)")
ax.set_title("A. 녹지율 vs 열섬지수  (원 크기 = 녹지 면적)", loc="left", fontsize=12, fontweight="bold", pad=10)
ax.grid(color=GRID, lw=0.8); ax.set_axisbelow(True)
ax.legend(handles=[Line2D([], [], marker="o", ls="", color=c, label=n, markersize=10) for n, c in COLOR.items()],
          loc="lower right", bbox_to_anchor=(1.0, 1.0), frameon=False, ncol=4,
          fontsize=9.5, columnspacing=1.0, handletextpad=0.2)

# (B) 우선 조성 순위 (가로 막대)
ax = fig.add_subplot(gs[0, 1])
d = df.iloc[::-1]
bars = ax.barh(d["행정구"], d["우선조성점수"], color=d["구분"].map(COLOR), height=0.62)
for b, (_, r) in zip(bars, d.iterrows()):
    ax.text(b.get_width() + 0.015, b.get_y() + b.get_height() / 2,
            f'{r["우선조성점수"]:.2f}', va="center", fontsize=11, fontweight="bold")
ax.set_xlim(0, 1.12)
ax.set_xlabel("우선 조성 점수  (열섬지수 + 녹지부족지수) / 2")
ax.set_title("B. 녹지 우선 조성 권장 순위", loc="left", fontsize=12, fontweight="bold", pad=10)
ax.grid(axis="x", color=GRID, lw=0.8); ax.set_axisbelow(True); ax.spines["left"].set_visible(False)
ax.tick_params(axis="y", length=0, labelsize=12)

# (C) 요약 표
ax = fig.add_subplot(gs[1, :])
ax.axis("off")
ax.set_title("C. 구·군별 지표 요약", loc="left", fontsize=13, fontweight="bold", pad=6)
tab = pd.DataFrame({
    "순위": df["우선순위"],
    "구·군": df["행정구"],
    "녹지면적 (㎢)": (df["녹지면적"] / 1e6).map("{:,.1f}".format),
    "녹지율 (%)": df["녹지율"].map("{:.1f}".format),
    "평균최고기온 (℃)": df["평균최고기온"].map("{:.1f}".format),
    "열대야 (일)": df["열대야일수"].astype(int),
    "우선조성 점수": df["우선조성점수"].map("{:.2f}".format),
    "구분": df["구분"],
})
t = ax.table(cellText=tab.values, colLabels=tab.columns, loc="upper center", cellLoc="center",
             bbox=[0.02, 0.0, 0.96, 0.9])
t.auto_set_font_size(False); t.set_fontsize(11.5)
for (i, j), cell in t.get_celld().items():
    cell.set_edgecolor(GRID)
    if i == 0:
        cell.set_facecolor("#243B53"); cell.set_text_props(color="white", fontweight="bold")
    else:
        cell.set_facecolor("#F7F9FB" if i % 2 == 0 else "white")
        if j == len(tab.columns) - 1:
            cell.set_text_props(color=COLOR[tab.iloc[i - 1, j]], fontweight="bold")

fig.text(0.06, 0.012,
         "※ 동구·중구는 신암 관측소 값을 공유 / 남구·수성구는 관측소 데이터 부재로 제외 / "
         "열대야=일 최저기온 25℃ 이상(2026.7), 녹지는 2024년 기준으로 시점이 다름 / 표본 수가 적어 상관은 참고용",
         fontsize=9.5, color="#7B8794")

# 구·군별 열대야일수 (관측소 기준)
p = df.sort_values("열대야일수", ascending=False)
fig2, ax2 = plt.subplots(figsize=(9, 5))
bars = ax2.bar(p["행정구"], p["열대야일수"], color="#C0392B", width=0.6)
for b, v in zip(bars, p["열대야일수"]):
    ax2.text(b.get_x() + b.get_width() / 2, v + 0.4, f"{v}일", ha="center", fontsize=11, fontweight="bold")
ax2.set_ylabel("열대야 일수 (일)")
ax2.set_title("구·군별 열대야 일수 (AWS 관측소 기준, 2026.7)", fontweight="bold", loc="left")
fig2.text(0.01, 0.01, "※ 동구·중구는 신암 관측소 값 공유 / 열대야=일 최저기온 25℃ 이상",
          fontsize=9, color="#7B8794")
plt.tight_layout(rect=(0, 0.03, 1, 1))

plt.show()