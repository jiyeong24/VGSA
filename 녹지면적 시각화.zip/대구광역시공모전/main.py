from matplotlib.ticker import MultipleLocator
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm

#ASOS 데이터 불러오기
results=[]

for year in range(2016,2026):
  file_path=f"data/{year}_ASOS.csv"
  try:
    df=pd.read_csv(file_path, encoding="cp949")
    df["일시"]=pd.to_datetime(df["일시"])
    df["월"]=df["일시"].dt.month

    summer_df=df[df["월"].isin([6,7,8])]

    avg_max_temp = summer_df["최고기온(°C)"].mean()
    tropical_nights=(summer_df["최저기온(°C)"]>=25).sum()

    results.append({
        "연도": year,
        "평균 최고기온": avg_max_temp,
        "열대야 일수(일)": tropical_nights
    })
  except FileNotFoundError:
      print(f"{file_path} 파일을 찾을 수 없습니다.")

result_df=pd.DataFrame(results)
print(result_df)


plt.rc("font",family="Malgun Gothic")
plt.rc("axes", unicode_minus=False)


sns.barplot(data=result_df, x="연도", y="열대야 일수(일)")
plt.show()

#AWS 데이터 불러오기
results_AWS=[]

Latest_AWS = pd.read_csv("data/Latest_AWS.csv", encoding="cp949")

Latest_AWS["일시"]=pd.to_datetime(Latest_AWS["일시"])
mask=(Latest_AWS["일시"]>="2025-06-01") &(Latest_AWS["일시"]<="2025-08-31")
summer_AWS=Latest_AWS.loc[mask].copy()

daily_summary=(
   summer_AWS.groupby(summer_AWS["일시"])
   .agg(
      평균최고기온=("최고기온(°C)", "mean"),
      열대야일수=("최저기온(°C)", "mean"),
   )
   .reset_index()
)

print(daily_summary)
plt.figure(figsize=(12,6))
plt.plot(daily_summary["일시"], daily_summary["평균최고기온"], label="평균 최고기온")
plt.legend()
plt.show()


plt.rcParams["font.family"] = "Malgun Gothic"   # 한글 깨짐 방지 (Mac은 "AppleGothic")
plt.rcParams["axes.unicode_minus"] = False

# 1) 읽기 + 멀티헤더 평탄화 (같은 이름이 반복되면 한 번만 사용)
Green = pd.read_csv("data/GreenArea.csv", encoding="cp949", header=[0, 1, 2])

def flatten(col):
    parts = []
    for c in col:
        c = str(c).strip()
        if not c.startswith("Unnamed") and c not in parts:
            parts.append(c)
    return "_".join(parts)

Green.columns = [flatten(col) for col in Green.columns]

# 2) 앞 두 컬럼을 바로 "시도", "행정구"로 확정
Green = Green.rename(columns={Green.columns[0]: "시도", Green.columns[1]: "행정구"})

# 3) 대구광역시만, 소계/합계 행 제외
green_df = Green[
    Green["시도"].astype(str).str.startswith("대구광역시")
    & ~Green["행정구"].astype(str).str.strip().isin(["소계", "합계"])
].copy()

# 4) 합산 대상 컬럼: 4개 종류 + '면적' (비율 컬럼 제외)
target_categories = ["활엽수림", "침엽수림", "혼효림", "자연초지"]
Green_cols = [
    col for col in green_df.columns
    if any(cat in col for cat in target_categories) and "면적" in col
]
print("----- 합산 대상 컬럼 -----")
print(Green_cols)   # 정확히 4개인지 확인 (연도가 여러 개면 8개 등으로 늘어남)

# 5) 숫자 변환
for col in Green_cols:
    green_df[col] = pd.to_numeric(
        green_df[col].astype(str).str.replace(",", "").str.replace(" ", ""),
        errors="coerce",
    ).fillna(0)

# 6) 총 녹지면적 계산
green_df["총 녹지면적(m²)"] = green_df[Green_cols].sum(axis=1)

# 7) 오름차순 정렬
result_view = (
    green_df[["시도", "행정구", "총 녹지면적(m²)"]]
    .sort_values("총 녹지면적(m²)", ascending=True)
    .reset_index(drop=True)
)

print("\n--- 대구시 구·군별 녹지 면적 취약 순위 (오름차순) ---")
print(result_view.to_string(index=False))
print("\n총 녹지면적이 가장 적은 지역:", result_view.loc[0, "행정구"])


# 8) 막대그래프 (정렬 순서 그대로)
plt.figure(figsize=(12, 6))
ax = sns.barplot(data=result_view, x="행정구", y="총 녹지면적(m²)", order=result_view["행정구"])
ax.set_yscale("log")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()


from heat_data import heat
merged_df=pd.merge(result_view, heat, on="행정구", how="inner")
print(merged_df)

plot_df = merged_df.sort_values("총 녹지면적(m²)")

fig, ax1 = plt.subplots(figsize=(11, 6))
ax1.bar(plot_df["행정구"], plot_df["총 녹지면적(m²)"], color="#6aaa64")
ax1.set_ylabel("총 녹지면적 (m²)")
ax1.set_yscale("log")

ax2 = ax1.twinx()
ax2.plot(plot_df["행정구"], plot_df["평균최고기온"], color="#d62728", marker="o", linewidth=2)
ax2.set_ylabel("평균최고기온 (℃)", color="#d62728")

plt.title("구·군별 녹지면적과 평균최고기온 (녹지 적은 순)")
plt.tight_layout()
plt.show()


import viz_pro
final_df=viz_pro.df
print(final_df["행정구","녹지율","평균최고기온","열대야일수","우선조성점수","구분"]).round(2)