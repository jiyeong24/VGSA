import altair as alt
import pandas as pd
import streamlit as st

from data_st import load_asos, load_green, load_heat, build_result

st.set_page_config(page_title="대구 열섬·녹지 분석", page_icon="🌳", layout="wide")

COLOR = {"최우선": "#C0392B", "열 관리": "#E67E22", "녹지 확충": "#2E6F9E", "양호": "#3A8F5C"}
color_scale = alt.Scale(domain=list(COLOR), range=list(COLOR.values()))


@st.cache_data
def get_asos():
    return load_asos()


@st.cache_data
def get_green():
    return load_green()


@st.cache_data
def get_heat():
    return load_heat()


asos, green, heat = get_asos(), get_green(), get_heat()

# ───────── 사이드바 ─────────
st.sidebar.header("분석 설정")
exclude = st.sidebar.multiselect(
    "분석에서 제외할 구·군",
    options=sorted(heat["행정구"].unique()),
    default=["서구"],
    help="서구·달성군 AWS 파일이 동일해 서구를 기본 제외했습니다. 파일을 다시 받은 뒤에는 비워 두세요.",
)
w_heat = st.sidebar.slider("열섬 가중치 (나머지는 녹지 부족)", 0.0, 1.0, 0.5, 0.1)

df, t_mid, g_mid = build_result(green, heat, exclude, w_heat)
if len(df) < 2:
    st.error("비교할 구·군이 2곳 이상 필요합니다. 제외 목록을 줄여 주세요.")
    st.stop()

# ───────── 헤더 ─────────
st.title("🌳 대구 도심 열섬과 녹지 불균형 분석")
st.caption("기온: 기상청 AWS(2026.7) · 녹지: KOSIS 토지피복지도(2024) · 연도별 추세: ASOS(2016~2025, 6~8월)")

top = df.iloc[0]
hot_names = df[df["열대야일수"] == df["열대야일수"].max()]["행정구"].tolist()
low_green = green.sort_values("녹지율").iloc[0]

m1, m2, m3 = st.columns(3)
m1.metric("우선 조성 1순위", top["행정구"], f'점수 {top["우선조성점수"]:.2f}', delta_color="off")
m2.metric("녹지율 최저", low_green["행정구"], f'{low_green["녹지율"]:.1f}%', delta_color="off")
m3.metric("열대야 최다 (관측소 기준)", " · ".join(hot_names),
          f'{int(df["열대야일수"].max())}일', delta_color="off")

tab1, tab2, tab3, tab4, tab5 = st.tabs(
    ["① 연도별 추세", "② 구·군별 녹지", "③ 열섬 × 녹지", "④ 요약 표", "⑤ 데이터 한계"]
)

# ───────── ① 연도별 추세 ─────────
with tab1:
    c1, c2 = st.columns(2)
    with c1:
        st.subheader("연도별 열대야 일수")
        bar = alt.Chart(asos).mark_bar(color="#2E6F9E").encode(
            x=alt.X("연도:O", axis=alt.Axis(labelAngle=0)),
            y=alt.Y("열대야일수:Q", title="열대야 일수(일)"),
            tooltip=["연도", "열대야일수"],
        )
        txt = bar.mark_text(dy=-6).encode(text="열대야일수:Q")
        st.altair_chart((bar + txt).properties(height=320, width="container"))
    with c2:
        st.subheader("연도별 여름철 평균최고기온")
        line = alt.Chart(asos).mark_line(point=True, color="#C0392B").encode(
            x=alt.X("연도:O", axis=alt.Axis(labelAngle=0)),
            y=alt.Y("평균최고기온:Q", scale=alt.Scale(zero=False), title="평균최고기온(℃)"),
            tooltip=["연도", "평균최고기온"],
        )
        st.altair_chart(line.properties(height=320, width="container"))

    st.subheader("평균최고기온과 열대야 일수의 관계")
    sc = alt.Chart(asos).mark_circle(size=130, color="#C0392B").encode(
        x=alt.X("평균최고기온:Q", scale=alt.Scale(zero=False), title="여름철 평균최고기온(℃)"),
        y=alt.Y("열대야일수:Q", title="열대야 일수(일)"),
        tooltip=["연도", "평균최고기온", "열대야일수"],
    )
    lbl = sc.mark_text(dx=12, align="left").encode(text="연도:N")
    st.altair_chart((sc + lbl).properties(height=340, width="container"))
    st.caption("대구 1개 지점(ASOS) 기준이라 구·군별 차이는 ③에서 확인합니다.")

# ───────── ② 구·군별 녹지 ─────────
with tab2:
    gp = green.sort_values("녹지율").copy()
    avg = green["녹지면적_km2"].sum() / green["전체면적_km2"].sum() * 100
    gp["수준"] = gp["녹지율"].apply(lambda v: "10% 미만" if v < 10 else "10% 이상")
    order = list(gp["행정구"])

    st.subheader("구·군별 녹지율 (2024)")
    bars = alt.Chart(gp).mark_bar().encode(
        x=alt.X("행정구:N", sort=order, axis=alt.Axis(labelAngle=0), title=None),
        y=alt.Y("녹지율:Q", title="녹지율(%)"),
        color=alt.Color("수준:N", legend=None,
                        scale=alt.Scale(domain=["10% 미만", "10% 이상"], range=["#C0392B", "#3A8F5C"])),
        tooltip=["행정구", alt.Tooltip("녹지율:Q", format=".1f"),
                 alt.Tooltip("녹지면적_km2:Q", format=".1f", title="녹지면적(㎢)")],
    )
    txt = bars.mark_text(dy=-8).encode(text=alt.Text("녹지율:Q", format=".1f"))
    rule = alt.Chart(pd.DataFrame({"y": [avg]})).mark_rule(
        strokeDash=[5, 4], color="gray").encode(y="y:Q")
    st.altair_chart((bars + txt + rule).properties(height=340, width="container"))
    st.caption(f"점선: 대구 전체 평균 녹지율 {avg:.1f}% (녹지율 = 녹지면적 / 구·군 전체 면적)")

    st.subheader("구·군별 총 녹지면적")
    use_log = st.checkbox("로그 스케일", value=True)
    yscale = alt.Scale(type="log", domainMin=0.01) if use_log else alt.Scale()
    area = alt.Chart(gp).mark_bar(color="#6aaa64").encode(
        x=alt.X("행정구:N", sort=order, axis=alt.Axis(labelAngle=0), title=None),
        y=alt.Y("녹지면적_km2:Q", scale=yscale, title="녹지면적(㎢)"),
        tooltip=["행정구", alt.Tooltip("녹지면적_km2:Q", format=".1f", title="녹지면적(㎢)")],
    )
    st.altair_chart(area.properties(height=300, width="container"))

# ───────── ③ 열섬 × 녹지 ─────────
with tab3:
    st.subheader("녹지율 vs 열섬지수 (원 크기 = 녹지면적)")
    xmax = df["녹지율"].max() * 1.15
    xs, ys = alt.Scale(domain=[-5, xmax]), alt.Scale(domain=[-0.2, 1.2])
    tips = ["행정구", "구분",
            alt.Tooltip("녹지율:Q", format=".1f"),
            alt.Tooltip("평균최고기온:Q", format=".1f", title="평균최고기온(℃)"),
            "열대야일수",
            alt.Tooltip("우선조성점수:Q", format=".2f")]

    base = alt.Chart(df)
    pts = base.mark_circle(opacity=0.85, stroke="white", strokeWidth=2).encode(
        x=alt.X("녹지율:Q", scale=xs, title="녹지율(%) → 높을수록 녹지 풍부"),
        y=alt.Y("열섬지수:Q", scale=ys, title="열섬지수 (평균최고기온 + 열대야일수)"),
        size=alt.Size("녹지면적_km2:Q", scale=alt.Scale(range=[300, 2500]), legend=None),
        color=alt.Color("구분:N", scale=color_scale, legend=alt.Legend(orient="top", title=None)),
        tooltip=tips,
    )
    names = base.mark_text(dy=-24, fontSize=13, fontWeight="bold").encode(
        x=alt.X("녹지율:Q", scale=xs), y=alt.Y("열섬지수:Q", scale=ys), text="행정구:N")
    vline = alt.Chart(pd.DataFrame({"x": [g_mid]})).mark_rule(
        strokeDash=[5, 4], color="#9AA5B1").encode(x=alt.X("x:Q", scale=xs))
    hline = alt.Chart(pd.DataFrame({"y": [t_mid]})).mark_rule(
        strokeDash=[5, 4], color="#9AA5B1").encode(y=alt.Y("y:Q", scale=ys))

    c1, c2 = st.columns([1.3, 1])
    with c1:
        st.altair_chart((pts + names + vline + hline).properties(height=420, width="container"))
        st.caption("왼쪽 위(녹지율 낮고 열섬지수 높음)가 최우선 조성 구역입니다. 점선은 중앙값 기준입니다.")
    with c2:
        st.subheader("녹지 우선 조성 순위")
        rank = alt.Chart(df).mark_bar().encode(
            y=alt.Y("행정구:N", sort=list(df["행정구"]), title=None),
            x=alt.X("우선조성점수:Q", scale=alt.Scale(domain=[0, 1.1]), title="우선 조성 점수"),
            color=alt.Color("구분:N", scale=color_scale, legend=None),
            tooltip=["행정구", "구분", alt.Tooltip("우선조성점수:Q", format=".2f")],
        )
        rtxt = rank.mark_text(align="left", dx=4).encode(
            text=alt.Text("우선조성점수:Q", format=".2f"))
        st.altair_chart((rank + rtxt).properties(height=420, width="container"))

    c3, c4 = st.columns(2)
    with c3:
        st.subheader("구·군별 열대야 일수")
        hb = alt.Chart(df).mark_bar(color="#C0392B").encode(
            x=alt.X("행정구:N", sort="-y", axis=alt.Axis(labelAngle=0), title=None),
            y=alt.Y("열대야일수:Q", title="열대야 일수(일)"),
            tooltip=["행정구", "열대야일수"])
        ht = hb.mark_text(dy=-8).encode(text="열대야일수:Q")
        st.altair_chart((hb + ht).properties(height=300, width="container"))
    with c4:
        st.subheader("구·군별 평균최고기온")
        tb = alt.Chart(df).mark_bar(color="#E67E22").encode(
            x=alt.X("행정구:N", sort="-y", axis=alt.Axis(labelAngle=0), title=None),
            y=alt.Y("평균최고기온:Q", scale=alt.Scale(zero=False), title="평균최고기온(℃)"),
            tooltip=["행정구", alt.Tooltip("평균최고기온:Q", format=".1f")])
        st.altair_chart(tb.properties(height=300, width="container"))
    st.caption("동구·중구는 신암 관측소 값을 공유하므로 같은 값입니다. 열대야 = 일 최저기온 25℃ 이상(2026.7).")

# ───────── ④ 요약 표 ─────────
with tab4:
    st.subheader("구·군별 지표 요약")
    view = df[["우선순위", "행정구", "녹지면적_km2", "녹지율", "평균최고기온",
               "열대야일수", "우선조성점수", "구분"]].rename(columns={
        "행정구": "구·군", "녹지면적_km2": "녹지면적(㎢)", "녹지율": "녹지율(%)",
        "평균최고기온": "평균최고기온(℃)", "열대야일수": "열대야(일)"})
    st.dataframe(view.round(2), hide_index=True)
    st.download_button("요약 표 CSV 다운로드",
                       view.round(2).to_csv(index=False).encode("utf-8-sig"),
                       file_name="대구_열섬_녹지_요약.csv", mime="text/csv")
    with st.expander("전체 9개 구·군 녹지 현황"):
        st.dataframe(green.round(2), hide_index=True)

# ───────── ⑤ 데이터 한계 ─────────
with tab5:
    st.markdown("""
- 구·군별 기온은 **관측소 값을 구·군에 대응시킨 근사값**입니다. 동구·중구는 신암 관측소를 공유합니다.
- **남구·수성구**는 관측소 자료가 없어 제외했습니다.
- **서구·달성군** AWS 파일이 동일해 서구를 기본 제외했고, 달성군 값도 확인이 필요합니다.
- 기온은 2026년 7월, 녹지는 2024년 기준으로 **시점이 다릅니다.**
- 분석 대상이 6개 구·군이라 상관관계는 **참고용**입니다.
- 우선조성점수의 가중치(기본 1:1)는 임의 설정입니다. 사이드바에서 바꿔 민감도를 확인할 수 있습니다.
""")