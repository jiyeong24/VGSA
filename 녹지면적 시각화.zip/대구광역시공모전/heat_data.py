import pandas as pd

#군위군 데이터 수집
Gunwi = pd.read_csv("data/AWS_202607_군위군.csv", encoding="cp949")
Gunwi["일시"]=pd.to_datetime(Gunwi["일시"])

temp_col="기온(°C)"
Gunwi[temp_col]=pd.to_numeric(Gunwi[temp_col],errors="coerce")

Gunwi["날짜"]=Gunwi["일시"].dt.date
daily_max_gunwi=Gunwi.groupby("날짜")[temp_col].max()

avg_max_temp_gunwi=daily_max_gunwi.mean()
print(f"군위군 최고 평균 기온:{avg_max_temp_gunwi}")

#북구 데이터 수집
Bukgu=pd.read_csv("data/AWS_202607_북구.csv",encoding="cp949")
Bukgu["일시"]=pd.to_datetime(Bukgu["일시"])

Bukgu[temp_col]=pd.to_numeric(Bukgu[temp_col],errors="coerce")

Bukgu["날짜"]=Bukgu["일시"].dt.date
daily_max_bukgu=Bukgu.groupby("날짜")[temp_col].max()


avg_max_temp_bukgu=daily_max_bukgu.mean()
print(f"북구 최고 평균 기온:{avg_max_temp_bukgu}")

#서구 데이터 수집
Seogu=pd.read_csv("data/AWS_202607_서구.csv",encoding="cp949")
Seogu["일시"]=pd.to_datetime(Seogu["일시"])

Seogu[temp_col]=pd.to_numeric(Seogu[temp_col],errors="coerce")

Seogu["날짜"]=Seogu["일시"].dt.date
daily_max_Seogu=Seogu.groupby("날짜")[temp_col].max()

avg_max_temp_Seogu=daily_max_Seogu.mean()
print(f"서구 최고 평균 기온:{avg_max_temp_Seogu}")

#달성군 데이터 수집
Dalseong=pd.read_csv("data/AWS_202607_달성군.csv",encoding="cp949")
Dalseong["일시"]=pd.to_datetime(Dalseong["일시"])

Dalseong[temp_col]=pd.to_numeric(Dalseong[temp_col],errors="coerce")

Dalseong["날짜"]=Dalseong["일시"].dt.date
daily_max_dalseong=Dalseong.groupby("날짜")[temp_col].max()

avg_max_temp_dalseong=daily_max_dalseong.mean()
print(f"달성군 최고 평균 기온:{avg_max_temp_dalseong}")

#동구, 중구(신암) 데이터 수집
Sinam=pd.read_csv("data/AWS_202607_신암(동구).csv",encoding="cp949")
Sinam["일시"]=pd.to_datetime(Sinam["일시"])

Sinam[temp_col]=pd.to_numeric(Sinam[temp_col],errors="coerce")

Sinam["날짜"]=Sinam["일시"].dt.date
daily_max_sinam=Sinam.groupby("날짜")[temp_col].max()

avg_max_temp_sinam=daily_max_sinam.mean()
print(f"신암(동구,중구) 최고 평균 기온:{avg_max_temp_sinam}")

#달서구(옥포) 데이터 수집
Okpo=pd.read_csv("data/AWS_202607_옥포(달서구).csv",encoding="cp949")
Okpo["일시"]=pd.to_datetime(Okpo["일시"])

Okpo[temp_col]=pd.to_numeric(Okpo[temp_col],errors="coerce")

Okpo["날짜"]=Okpo["일시"].dt.date
daily_max_okpo=Okpo.groupby("날짜")[temp_col].max()

avg_max_temp_okpo=daily_max_okpo.mean()
print(f"옥포(달서구) 최고 평균 기온:{avg_max_temp_okpo}")

def station_stats(df):
  jul=df[df["일시"].dt.month==7]
  day=jul.groupby(jul["일시"].dt.date)[temp_col]
  dmax, dmin=day.max(), day.min()
  return{
    "평균최고기온":dmax.mean(),
    "열대야일수":int((dmin>=25).sum()),
    "폭염일수":int((dmax>=35).sum()),
  }

stations=[
  (Gunwi, ["군위군"]),
  (Bukgu, ["북구"]),
  (Seogu, ["서구"]),
  (Dalseong, ["달성군"]),
  (Sinam, ["동구","중구"]),
  (Okpo, ["달서구"]),
]

rows=[]
for df_, gus in stations:
  st=station_stats(df_)
  for gu in gus:
    rows.append({"행정구":gu,**st})

heat=pd.DataFrame(rows)

if __name__=="__main__":
  print(heat.round(2))